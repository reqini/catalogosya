import React, { useState, useEffect, useCallback } from "react";
import {
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Snackbar,
  Alert
} from "@mui/material";
import axios from "./utils/axios";
import Navbar from "./components/Navbar";

const Emprendedoras = () => {
  const [clientes, setClientes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);

  // 📌 Función reutilizable para fetch de clientes
  const fetchClientes = useCallback(async () => {
    try {
      console.log("🔍 Fetching clientes...");
      const { data } = await axios.get("/api/clientes");
      console.log("✅ Clientes recibidos:", data);

      if (Array.isArray(data)) {
        setClientes(data);
      } else {
        console.error("⚠️ La API no devolvió un array de clientes:", data);
        setError("Formato de datos incorrecto");
      }
    } catch (error) {
      console.error("🚨 Error al obtener clientes:", error);
      setError("No se pudieron cargar los clientes.");
    } finally {
      setLoading(false);
    }
  }, []);

  // 📌 Cargar clientes al montar el componente
  useEffect(() => {
    fetchClientes();
  }, [fetchClientes]);

  // 📌 Cerrar snackbar
  const handleSnackbarClose = (event, reason) => {
    if (reason === "clickaway") return;
    setSnackbarOpen(false);
  };

  return (
    <>
      <Navbar title="Panel de Emprendedoras" user={{ username: localStorage.getItem("activeSession") || "" }} />

      <Container style={{ marginTop: 30 }}>
        <Typography variant="h4" gutterBottom>
          Listado de Clientes
        </Typography>

        {/* 📌 Indicador de carga */}
        {loading && (
          <div style={{ textAlign: "center", marginTop: 20 }}>
            <CircularProgress />
            <Typography variant="body1">Cargando clientes...</Typography>
          </div>
        )}

        {/* 📌 Mostrar error si la carga falla */}
        {error && (
          <Typography variant="body1" color="error" align="center">
            {error}
          </Typography>
        )}

        {/* 📌 TABLA DE CLIENTES */}
        {!loading && !error && (
          <TableContainer component={Paper} style={{ marginTop: 20 }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell><strong>Nombre</strong></TableCell>
                  <TableCell><strong>Dirección</strong></TableCell>
                  <TableCell><strong>Banco</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {clientes.length > 0 ? (
                  clientes.map((cliente, idx) => (
                    <TableRow key={idx}>
                      <TableCell>{cliente.nombre}</TableCell>
                      <TableCell>{cliente.direccion}</TableCell>
                      <TableCell>{cliente.banco}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} style={{ textAlign: "center" }}>
                      No hay clientes registrados.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        )}

        {/* 📌 Notificación Snackbar */}
        <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose}>
          <Alert onClose={handleSnackbarClose} severity="success">
            Cliente agregado correctamente.
          </Alert>
        </Snackbar>
      </Container>
    </>
  );
};

export default Emprendedoras;
