# Catalogo Simple

## Como Ejecutarlo desde cero:

### npm install / yarn
### npm start / yarn start