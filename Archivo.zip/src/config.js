export const SHEETS = {
  RESERVAS: "1zB8-2WtpUkrRHhcWEbYHcrIP9HZPsgP2Fy3QVeTCUA0", // 🆕 ID de la hoja de reservas
};
