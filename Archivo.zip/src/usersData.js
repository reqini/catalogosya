const usersData = [
    { username: 'cocinaty', password: '279323' },
    { username: 'lety', password: '303649' },
    { username: 'tory', password: '295467' },
    // Agrega más usuarios según sea necesario
  ];
  
export default usersData;