import React, { useState } from "react";
import {
  Container,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
} from "@mui/material";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";

const placeholderImage = "/placeholder.png";

const NailsCatalogo = ({ product }) => {
  const [open, setOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [clientName, setClientName] = useState("");
  const [phone, setPhone] = useState("");

const handleReserve = async () => {
  if (!selectedDate || !selectedTime || !clientName || !phone) {
    alert("Por favor, completa todos los campos antes de reservar.");
    return;
  }

  const formattedDate = selectedDate.toISOString().split("T")[0]; 
  const formattedTime = selectedTime.toLocaleTimeString();
  const apiUrl = "https://script.google.com/macros/s/AKfycbxtBe2dqBuXZsea3RPpEA-LnDhPkXFleyoOxy852kYZGVwDV6Dtppm0DoflEoqp6O8tkQ/exec";

  const requestBody = {
    nombreCliente: clientName,
    dia: formattedDate,
    hora: formattedTime,
    tipoUñas: product["Nombre del Producto"],
    telefono: phone,
  };

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
      mode: "cors" // 🔥 Solución al problema de CORS
    });

    const result = await response.json();
    if (result.success) {
      sendWhatsApp();
      setOpen(true); // Muestra modal de confirmación
    } else {
      alert("Hubo un problema con la reserva: " + result.message);
    }
  } catch (error) {
    console.error("Error al guardar la reserva:", error);
    alert("Error al guardar la reserva. Verifica tu conexión o la API.");
  }
};


  const sendWhatsApp = () => {
  const formattedDate = selectedDate.toISOString().split("T")[0];
  const formattedTime = selectedTime.toLocaleTimeString();
  const message = `Hola ${clientName}! 🎉 Tu turno para *${product["Nombre del Producto"]}* ha sido reservado el *${formattedDate}* a las *${formattedTime}*. Gracias por elegirnos! 💅✨`;

  const ownerMessage = `📢 Nueva Reserva Recibida! 
  - Cliente: ${clientName}
  - Teléfono: ${phone}
  - Servicio: ${product["Nombre del Producto"]}
  - Fecha: ${formattedDate}
  - Hora: ${formattedTime}`;

  // Crear link de WhatsApp para el cliente
  const clientWhatsAppURL = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;

  // Crear link de WhatsApp para el dueño del negocio
  const ownerWhatsAppURL = `https://wa.me/5491123175048?text=${encodeURIComponent(ownerMessage)}`;

  // Abrir ambos mensajes en pestañas nuevas
  window.open(clientWhatsAppURL, "_blank"); 
  setTimeout(() => {
    window.open(ownerWhatsAppURL, "_blank"); 
  }, 2000); // Pequeño delay para evitar bloqueos
};



  return (
    <Container maxWidth="sm">
      <Card sx={{ boxShadow: 3, borderRadius: 2 }}>
        <CardMedia
          component="img"
          height="250"
          image={product["Imagen/Link a Imagen"] || placeholderImage}
          alt={product["Nombre del Producto"] || "Modelo de uñas"}
          sx={{ objectFit: "cover" }}
        />
        <CardContent>
          <Typography variant="h6" fontWeight="bold">
            {product["Nombre del Producto"] || "Modelo de uñas"}
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            {product["Descripción"] || "Elige tu diseño y reserva tu turno"}
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Nombre"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Teléfono"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </Grid>
            <Grid item xs={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Seleccionar Fecha"
                  value={selectedDate}
                  onChange={(newDate) => setSelectedDate(newDate)}
                  textField={(params) => <TextField {...params} fullWidth />}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <TimePicker
                  label="Seleccionar Hora"
                  value={selectedTime}
                  onChange={(newTime) => setSelectedTime(newTime)}
                  textField={(params) => <TextField {...params} fullWidth />}
                />
              </LocalizationProvider>
            </Grid>
          </Grid>
        </CardContent>
        <Button
            variant="contained"
            color="primary"
            fullWidth
            onClick={handleReserve}
            >
            Reservar Turno
            </Button>

      </Card>
      {/* Modal de Confirmación */}
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>¡Reserva Confirmada!</DialogTitle>
        <DialogContent>
          <Typography>Tu turno ha sido reservado con éxito.</Typography>
          <Typography>Haz clic en "Enviar WhatsApp" para confirmar.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cerrar</Button>
          <Button onClick={sendWhatsApp} color="primary" variant="contained">
            Enviar WhatsApp
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default NailsCatalogo;