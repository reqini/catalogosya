import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { Button, CardActions, Chip, Grid, Box } from "@mui/material";
import { FaShoppingCart } from "react-icons/fa";

const placeholderImage = "/placeholder.png"; // Imagen por defecto

// Mapeo de nombres de colores a códigos HEX
const colorMap = {
  "Rojo": "#FF0000",
  "Azul": "#0000FF",
  "Negro": "#000000",
  "Blanco": "#FFFFFF",
  "Verde": "#008000",
  "Amarillo": "#FFFF00",
  "Gris": "#808080",
  "Marrón": "#A52A2A",
  "Rosa": "#FFC0CB",
  "Violeta": "#8A2BE2",
  "Celeste": "#87CEEB",
  "Naranja": "#FFA500",
};

// Función para convertir nombres de colores a HEX
const getColorHex = (colorName) => {
  return colorMap[colorName] || "#808080"; // Si no está en la lista, gris por defecto
};

const ProductsCatalogo = ({ product, onAddToCart }) => {
  // Usar imagen del producto o fallback si está vacía
  const productImage =
    product["Imagen/Link a Imagen"] && product["Imagen/Link a Imagen"].trim()
      ? product["Imagen/Link a Imagen"]
      : placeholderImage;

  // Obtener colores disponibles del Google Sheet y convertirlos en un array
  const coloresDisponibles = product["Colores Disponibles"]
    ? product["Colores Disponibles"].split(";").map((color) => color.trim())
    : [];

  return (
    <Card sx={{ maxWidth: 445, boxShadow: 3, borderRadius: 2 }}>
      {/* Imagen del producto */}
      <CardMedia
        component="img"
        height="200"
        image={productImage}
        alt={product["Nombre del Producto"] || "Producto"}
        sx={{ objectFit: "cover" }}
      />

      <CardContent>
        {/* Nombre del producto */}
        <Typography variant="h6" fontWeight="bold">
          {product["Nombre del Producto"] || "Producto sin nombre"}
        </Typography>

        {/* Descripción */}
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          {product["Descripción"] || "Descripción no disponible"}
        </Typography>

        {/* Marca y Categoría */}
        <Grid container spacing={1} sx={{ mb: 1 }}>
          <Grid item>
            <Chip color="secondary" label={`Marca: ${product["Marca"] || "Sin marca"}`} variant="outlined" />
          </Grid>
          <Grid item>
            <Chip color="secondary" label={`Categoría: ${product["Categoría"] || "Sin categoría"}`} variant="outlined" />
          </Grid>
        </Grid>

        {/* Precio */}
        <Typography variant="h6" color="secondary" fontWeight="bold">
          ${product["Precio de Venta"] || "Consultar"}
        </Typography>

        {/* Stock */}
        <Typography variant="body2" color="text.secondary">
          <b>Stock disponible:</b> {product["Stock Actual"] || "N/D"}
        </Typography>

        {/* Ubicación en almacén */}
        <Typography variant="body2" color="text.secondary">
          <b>Ubicación:</b> {product["Ubicación en Almacén"] || "No especificada"}
        </Typography>

        {/* Colores disponibles */}
        {coloresDisponibles.length > 0 && (
          <Box sx={{ display: "flex", alignItems: "center", mt: 1 }}>
            <Typography variant="body2" sx={{ mr: 1 }}>
              <b>Colores:</b>
            </Typography>
            {coloresDisponibles.map((color, index) => (
              <Box
                key={index}
                sx={{
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  backgroundColor: getColorHex(color),
                  border: "1px solid #ccc",
                  marginRight: 1,
                }}
                title={color} // Muestra el nombre del color al hacer hover
              />
            ))}
          </Box>
        )}
      </CardContent>

      <CardActions sx={{ justifyContent: "space-between", p: 2 }}>
        {/* Botón de agregar al carrito */}
        <Button
          fullWidth
          variant="contained"
          color="primary"
          startIcon={<FaShoppingCart />}
          onClick={() => onAddToCart(product)}
        >
          Agregar al carrito
        </Button>
      </CardActions>
    </Card>
  );
};

export default ProductsCatalogo;
